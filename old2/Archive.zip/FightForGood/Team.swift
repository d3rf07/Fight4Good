//
//  Team.swift
//  FightForGood
//
//  Created by d3rf on 09/08/2018.
//  Copyright © 2018 d3rf. All rights reserved.
//

import Foundation

class Team {
    
var name: String
var member1: Characters!
var member2: Characters!
var member3: Characters!
var giver: Characters!
var receiver: Characters!
    
 init (name: String) {
        self.name = name
//        self.member1 = nil
//        self.member2 = nil
//        self.member3 = nil
//        self.giver = nil
//        self.receiver = nil
    
    }
    
}


